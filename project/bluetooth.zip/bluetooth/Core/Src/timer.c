#include "timer.h"
#include "uart2.h"

#include "stm32f1xx_hal.h"
TIM_HandleTypeDef TIM3_Handler;

void TIM3_Init(u16 arr,u16 psc)
{
	__HAL_RCC_TIM3_CLK_ENABLE();

    TIM3_Handler.Instance=TIM3;
    TIM3_Handler.Init.Prescaler=psc;
    TIM3_Handler.Init.CounterMode=TIM_COUNTERMODE_UP;
    TIM3_Handler.Init.Period=arr;
    TIM3_Handler.Init.ClockDivision=TIM_CLOCKDIVISION_DIV1;
	TIM3_Handler.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_ENABLE;
    HAL_TIM_Base_Init(&TIM3_Handler);
    HAL_TIM_Base_Start_IT(&TIM3_Handler);

	HAL_NVIC_SetPriority(TIM3_IRQn,0,1);
	HAL_NVIC_EnableIRQ(TIM3_IRQn);


}

void TIM3_IRQHandler(void)
{

	if(__HAL_TIM_GET_FLAG(&TIM3_Handler,TIM_FLAG_UPDATE)!=RESET)
    {
        __HAL_TIM_CLEAR_IT(&TIM3_Handler,TIM_IT_UPDATE);
        USART2_RX_STA|=1<<15;
        __HAL_TIM_DISABLE(&TIM3_Handler);
    }

}

