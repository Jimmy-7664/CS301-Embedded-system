/* USER CODE BEGIN Header */
/**
 ******************************************************************************
 * @file           : main.c
 * @brief          : Main program body
 ******************************************************************************
 * @attention
 *
 * <h2><center>&copy; Copyright (c) 2020 STMicroelectronics.
 * All rights reserved.</center></h2>
 *
 * This software component is licensed by ST under BSD 3-Clause license,
 * the "License"; You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at:
 *                        opensource.org/licenses/BSD-3-Clause
 *
 ******************************************************************************
 */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "usart.h"
#include "gpio.h"
#include "stdio.h"
#include "delay.h"
#include "lcd.h"
#include <string.h>
#include "bluetooth.h"
#include "uart2.h"
/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/**
 * @brief  The application entry point.
 * @retval int
 */
#define U1_X1  20
#define U1_Y1  40
#define U2_X1  190
#define U2_Y1  100
int main(void) {
	/* USER CODE BEGIN 1 */
	u8 t,i;
	u8 key;
	RUN_STA run_mode=message;
	u8 reclen = 0, last_len = 0;
	u8 bluetooth_name[20];
	u32 DeviceID = *(u32*) (0x1ffff7e8);
	u8 u1_la = 0, u2_la = 0;
	u8 u1_last[128] = { 0 }, u2_last[128] = { 0 };
	BT_STA bt_sat = open;
	/* USER CODE END 1 */

	/* MCU Configuration--------------------------------------------------------*/

	/* Reset of all peripherals, Initializes the Flash interface and the Systick. */
	HAL_Init();

	/* USER CODE BEGIN Init */

	/* USER CODE END Init */

	/* Configure the system clock */
	SystemClock_Config();

	/* USER CODE BEGIN SysInit */
	delay_init(72);
	MX_GPIO_Init();
	LED_Init();
	KEY_Init();
	MX_USART1_UART_Init();
	LCD_Init();
	POINT_COLOR = RED;
	Bluetooth_Init();
	printf("BlueTooth Init OK\r\n");
	sprintf((char*) bluetooth_name, "blutooth_%04X", DeviceID % 100);
	HC_05_SET_NAME(bluetooth_name);
	//HC05_Get_Role();
	HC05_Role_Show();
	Picture_Draw(U1_X1, U1_Y1, gImage_slave);

	Picture_Draw(U2_X1, U2_Y1, gImage_user);
	HC05_Sta_Show(bt_sat);
//	LCD_ShowString(20, 40, 200, 24, 16, "Master Send :");
//	LCD_ShowString(20, 120, 200, 24, 16, "Slave Send :");

	/* USER CODE END SysInit */

	/* Initialize all configured peripherals */

	/* USER CODE BEGIN 2 */

	/* USER CODE END 2 */

	/* Infinite loop */
	/* USER CODE BEGIN WHILE */
	//HC05_Set_Cmd("AT+RESET");
	USART2_RX_STA = 0;
	int r=0;
	while (1) {
		t++;
		if (t > 5) {
			HC05_Sta_Show(bt_sat);
			t = 0;
		}

		key = KEY_Scan(0);

		if (key == WKUP_PRES) {
			u16 POINT=POINT_COLOR;
		    POINT_COLOR=BLUE;

				if (r == 0){
					r=1;
				     LCD_ShowString(10,20,200,24,16,"ROLE: master");
				}
				else{
					r=0;
				    LCD_ShowString(10,20,200,24,16,"ROLE: slave");
				}

		} else
		if (key == KEY0_PRES) //断开连接
		{
			bt_sat = open;
			u2_printf("OPEN");

//			HC05_Set_Cmd("AT+RESET");
//			HC05_KEY = 1;

		} else if (key == KEY1_PRES) //连接
		{
			bt_sat = close;
			u2_printf("CLOSE");
//			USART2_Init(38400);
//			HC05_Set_Cmd("AT+RESET");
//			USART2_Init(9600);
//	HC05_KEY = 0;
		}

		if (Usart_Success == 1) //PC端数据处理
				{

			if (strcmp((USART_RX_BUF), "AT\r\n") == 0) {
				bt_sat = close;
				HC05_KEY = 1;
				HC05_Set_Cmd("AT+RESET");
				printf("->>>AT MODE\r\n");
				HC05_KEY = 1;
				run_mode=at;
				USART2_Init(38400);


			} else if (strcmp((USART_RX_BUF), "MESSAGE\r\n") == 0) {
				printf("->>>MESSAGE MODE \r\n");
				USART2_Init(38400);
				HC05_Set_Cmd("AT+RESET");
				USART2_Init(9600);
				HC05_KEY = 0;
				run_mode=message;
				bt_sat = open;


			}else if(run_mode==at)
			{
				HC05_KEY=1;
				u2_printf("%s",USART_RX_BUF);
				HC05_KEY=0;
				printf("*******AT MODE***********\r\n");
				USART_RX_STA = 0;
				Usart_Success = 0;
				memset(USART_RX_BUF, 0, 200);
			}

			else if (strcmp((USART_RX_BUF), "CLOSE\r\n") == 0) {
				bt_sat = close;

				u2_printf("%s", USART_RX_BUF);


			} else if (strcmp((USART_RX_BUF), "OPEN\r\n") == 0) {
				bt_sat = open;

				u2_printf("%s", USART_RX_BUF);


			} else if (bt_sat == open) {

				POINT_COLOR = RED;
				HC05_KEY = 0;
				Usart_Success = 0;
				if (u1_la == 0) {
					u1_la = 1;

					LCD_Fill(U1_X1 + 60, U1_Y1 , U1_X1 + 200, U1_Y1 + 60,
							WHITE);
					LCD_ShowString(U1_X1 + 60, U1_Y1 , 200, 40, 24,
							USART_RX_BUF);
					strcpy((char*) u1_last, USART_RX_BUF);
				} else {
					if (u1_la == 1) {
						u1_la = 2;
						Picture_Draw(U1_X1, U1_Y1 + U2_Y1 + 30, gImage_slave);
					}
					LCD_Fill(U1_X1 + 60, 40 , 239, U1_Y1 + 60,WHITE);
					LCD_Fill(U1_X1 + 60, 180,239, 240, WHITE);

					LCD_ShowString(U1_X1 + 60, U1_Y1 , 200, 40, 24,u1_last);
					LCD_ShowString(U1_X1 + 60, U1_Y1 + 20 + U2_Y1 + 30, 200, 30,
							24, USART_RX_BUF);
					strcpy((char*) u1_last, USART_RX_BUF);
				}
				u2_printf("%s\r\n", USART_RX_BUF);
				printf("%s\r\n", USART_RX_BUF);

			}

				USART_RX_STA = 0;
				Usart_Success = 0;
				memset(USART_RX_BUF, 0, 200);


		}

		if ((USART2_RX_STA & 0X8000)) //蓝牙数据处理
		{
			for(i=0;i<5;i++)
			{
				LED1=!LED1;
				delay_ms(50);
			}
			LED1=0;
			reclen = USART2_RX_STA & 0X7FFF;
			USART2_RX_BUF[reclen] = 0;
			if(run_mode==at)
			{	USART2_RX_STA = 0;
				printf("%s",USART2_RX_BUF);

			}else
			if (USART2_RX_BUF[0] == 'A' && USART2_RX_BUF[1] == 'T'
					&& USART2_RX_BUF[2] == '+') {

				USART2_RX_STA = 0;
			} else if (strcmp((USART2_RX_BUF), "OPEN") == 0) {
				bt_sat = open;
				USART2_RX_STA = 0;

			} else if (strcmp((USART2_RX_BUF), "CLOSE") == 0) {
				bt_sat = close;
				USART2_RX_STA = 0;
			}
			else if (strcmp((USART2_RX_BUF), "OPEN\r\n") == 0) {
							bt_sat = open;
							USART2_RX_STA = 0;

						} else if (strcmp((USART2_RX_BUF), "CLOSE\r\n") == 0) {
							bt_sat = close;
							USART2_RX_STA = 0;
						}
			else {
				if (reclen < 20)
					reclen = 160 - 8 * reclen;
				else {
					reclen = 0;
				}
				POINT_COLOR = BLUE;
				if (u2_la == 0) {
					u2_la = 1;
					LCD_Fill(0, U2_Y1 + 20, 160, U2_Y1 + 40, WHITE);
					LCD_ShowString(reclen, U2_Y1 + 20, 155, 40, 24,
							USART2_RX_BUF);
					strcpy(u2_last, USART2_RX_BUF);
					last_len = reclen;
				} else {
					if (u2_la == 1) {
						u2_la = 2;
						Picture_Draw(U2_X1, U2_Y1+150, gImage_user);
					}
					LCD_Fill(0, U2_Y1, 180, U2_Y1 + 65, WHITE);
					LCD_ShowString(last_len, U2_Y1 + 20, 155, 40, 24,u2_last);

					LCD_Fill(0, 240, 160, 310, WHITE);
					LCD_ShowString(reclen, U2_Y1+20+140, 150, 32, 24,USART2_RX_BUF);
					strcpy(u2_last, USART2_RX_BUF);
					last_len = reclen;
				}
				printf("%s\r\n", USART2_RX_BUF);
				USART2_RX_STA = 0;

			}

		}

		/* USER CODE BEGIN 3 */
	}
	/* USER CODE END 3 */
}

/**
 * @brief System Clock Configuration
 * @retval None
 */
void SystemClock_Config(void) {
	RCC_OscInitTypeDef RCC_OscInitStruct = { 0 };
	RCC_ClkInitTypeDef RCC_ClkInitStruct = { 0 };

	/** Initializes the RCC Oscillators according to the specified parameters
	 * in the RCC_OscInitTypeDef structure.
	 */
	RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
	RCC_OscInitStruct.HSEState = RCC_HSE_ON;
	RCC_OscInitStruct.HSEPredivValue = RCC_HSE_PREDIV_DIV1;
	RCC_OscInitStruct.HSIState = RCC_HSI_ON;
	RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
	RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
	RCC_OscInitStruct.PLL.PLLMUL = RCC_PLL_MUL8;
	if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK) {
		Error_Handler();
	}
	/** Initializes the CPU, AHB and APB buses clocks
	 */
	RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK | RCC_CLOCKTYPE_SYSCLK
			| RCC_CLOCKTYPE_PCLK1 | RCC_CLOCKTYPE_PCLK2;
	RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
	RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
	RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
	RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

	if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK) {
		Error_Handler();
	}
}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/**
 * @brief  This function is executed in case of error occurrence.
 * @retval None
 */
void Error_Handler(void) {
	/* USER CODE BEGIN Error_Handler_Debug */
	/* User can add his own implementation to report the HAL error return state */

	/* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
 * @brief  Reports the name of the source file and the source line number
 *         where the assert_param error has occurred.
 * @param  file: pointer to the source file name
 * @param  line: assert_param error line source number
 * @retval None
 */
void assert_failed(uint8_t *file, uint32_t line) {
	/* USER CODE BEGIN 6 */
	/* User can add his own implementation to report the file name and line number,
	 tex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
	/* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
