#include "uart2.h"
#include "delay.h"
#include "sys.h"
#include "string.h"
#include <stdarg.h>
#include <stdio.h>
#include "timer.h"
#include "stdio.h"
UART_HandleTypeDef UART2_Handler;

 u8 USART2_TX_BUF[USART2_MAX_SEND_LEN];
u8 USART2_RX_BUF[USART2_MAX_RECV_LEN]; 				//½ÓÊÕ»º³å,×î´óUSART2_MAX_RECV_LEN¸ö×Ö½Ú.
vu16 USART2_RX_STA=0;
void USART2_Init(u32 bound)
{
	GPIO_InitTypeDef GPIO_Initure;
    __HAL_RCC_GPIOA_CLK_ENABLE();
    __HAL_RCC_USART2_CLK_ENABLE();

    GPIO_Initure.Pin=GPIO_PIN_2;
    GPIO_Initure.Mode=GPIO_MODE_AF_PP;
    GPIO_Initure.Pull=GPIO_PULLUP;
    GPIO_Initure.Speed=GPIO_SPEED_FREQ_HIGH;
    HAL_GPIO_Init(GPIOA,&GPIO_Initure);

	GPIO_Initure.Pin=GPIO_PIN_3;
	GPIO_Initure.Mode=GPIO_MODE_INPUT;
	HAL_GPIO_Init(GPIOA,&GPIO_Initure);

	UART2_Handler.Instance=USART2;					    //USART2
	UART2_Handler.Init.BaudRate=bound;
	UART2_Handler.Init.WordLength=UART_WORDLENGTH_8B;
	UART2_Handler.Init.StopBits=UART_STOPBITS_1;
	UART2_Handler.Init.Parity=UART_PARITY_NONE;
	UART2_Handler.Init.HwFlowCtl=UART_HWCONTROL_NONE;
	UART2_Handler.Init.Mode=UART_MODE_TX_RX;
	HAL_UART_Init(&UART2_Handler);

    __HAL_UART_ENABLE_IT(&UART2_Handler,UART_IT_RXNE);
	HAL_NVIC_EnableIRQ(USART2_IRQn);
	HAL_NVIC_SetPriority(USART2_IRQn,0,2);

	TIM3_Init(199,7199);
    __HAL_TIM_DISABLE(&TIM3_Handler);
	USART2_RX_STA=0;
}

void USART2_IRQHandler(void)
{
	u8 res;
	if((__HAL_UART_GET_FLAG(&UART2_Handler,UART_FLAG_RXNE)!=RESET))  //½ÓÊÕÖÐ¶Ï(½ÓÊÕµ½µÄÊý¾Ý±ØÐëÊÇ0x0d 0x0a½áÎ²)
	{
        HAL_UART_Receive(&UART2_Handler,&res,1,1000);
		if((USART2_RX_STA&(1<<15))==0)//½ÓÊÕÍêµÄÒ»ÅúÊý¾Ý,»¹Ã»ÓÐ±»´¦Àí,Ôò²»ÔÙ½ÓÊÕÆäËûÊý¾Ý
		{
			if(USART2_RX_STA<USART2_MAX_RECV_LEN)	//»¹¿ÉÒÔ½ÓÊÕÊý¾Ý
			{
                __HAL_TIM_SET_COUNTER(&TIM3_Handler,0);	//¼ÆÊýÆ÷Çå¿Õ
				if(USART2_RX_STA==0) 				//Ê¹ÄÜ¶¨Ê±Æ÷3µÄÖÐ¶Ï
				{
                    __HAL_TIM_ENABLE(&TIM3_Handler); //Ê¹ÄÜ¶¨Ê±Æ÷3
				}
				USART2_RX_BUF[USART2_RX_STA++]=res;	//¼ÇÂ¼½ÓÊÕµ½µÄÖµ
			}else
			{
				USART2_RX_STA|=1<<15;				//Ç¿ÖÆ±ê¼Ç½ÓÊÕÍê³É
			}
		}
    }
}
void u2_printf(char* fmt,...)
{
	u16 i,j;
	va_list ap;
	va_start(ap,fmt);
	vsprintf((char*)USART2_TX_BUF,fmt,ap);
	va_end(ap);
	i=strlen((const char*)USART2_TX_BUF);//´Ë´Î·¢ËÍÊý¾ÝµÄ³¤¶È
	for(j=0;j<i;j++)//Ñ­»··¢ËÍÊý¾Ý
	{
		while((USART2->SR&0X40)==0);//Ñ­»··¢ËÍ,Ö±µ½·¢ËÍÍê±Ï
		USART2->DR=USART2_TX_BUF[j];
	}
}

