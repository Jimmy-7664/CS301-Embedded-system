/**
  ******************************************************************************
  * File Name          : gpio.c
  * Description        : This file provides code for the configuration
  *                      of all used GPIO pins.
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2020 STMicroelectronics.
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by ST under BSD 3-Clause license,
  * the "License"; You may not use this file except in compliance with the
  * License. You may obtain a copy of the License at:
  *                        opensource.org/licenses/BSD-3-Clause
  *
  ******************************************************************************
  */

/* Includes ------------------------------------------------------------------*/
#include "gpio.h"
#include "sys.h"
#include "delay.h"
/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/*----------------------------------------------------------------------------*/
/* Configure GPIO                                                             */
/*----------------------------------------------------------------------------*/
/* USER CODE BEGIN 1 */

/* USER CODE END 1 */

/** Configure pins as
        * Analog
        * Input
        * Output
        * EVENT_OUT
        * EXTI
*/
void MX_GPIO_Init(void)
{

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOD_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();

}

void KEY_Init(void)
{

    GPIO_InitTypeDef GPIO_Initure;
    __HAL_RCC_GPIOA_CLK_ENABLE();           //¿ªÆôGPIOAÊ±ÖÓ
    __HAL_RCC_GPIOC_CLK_ENABLE();           //¿ªÆôGPIOCÊ±ÖÓ


    __HAL_RCC_GPIOA_CLK_ENABLE();           //¿ªÆôGPIOAÊ±ÖÓ
    __HAL_RCC_GPIOC_CLK_ENABLE();           //¿ªÆôGPIOCÊ±ÖÓ


    GPIO_Initure.Pin=GPIO_PIN_0;            //PA0
    GPIO_Initure.Mode=GPIO_MODE_INPUT;      //ÊäÈë
    GPIO_Initure.Pull=GPIO_PULLDOWN;        //ÏÂÀ­
    GPIO_Initure.Speed=GPIO_SPEED_FREQ_HIGH;//¸ßËÙ
    HAL_GPIO_Init(GPIOA,&GPIO_Initure);

	GPIO_Initure.Pin=GPIO_PIN_15; 			//PA15
    GPIO_Initure.Pull=GPIO_PULLUP;          //ÉÏÀ­
    HAL_GPIO_Init(GPIOA,&GPIO_Initure);

	GPIO_Initure.Pin=GPIO_PIN_5; 			//PC5
    GPIO_Initure.Pull=GPIO_PULLUP;          //ÉÏÀ­
    HAL_GPIO_Init(GPIOC,&GPIO_Initure);

}

u8 KEY_Scan(u8 mode)
{
	static u8 key_up=1;//°´¼ü°´ËÉ¿ª±êÖ¾
	if(mode)key_up=1;  //Ö§³ÖÁ¬°´
	if(key_up&&(KEY0==0||KEY1==0||WK_UP==1))
	{
		delay_ms(10);//È¥¶¶¶¯
		key_up=0;
		if(KEY0==0)return KEY0_PRES;
		else if(KEY1==0)return KEY1_PRES;
		else if(WK_UP==1)return WKUP_PRES;
	}else if(KEY0==1&&KEY1==1&&WK_UP==0)key_up=1;
	return 0;// ÎÞ°´¼ü°´ÏÂ
}

void LED_Init(void)
{
    GPIO_InitTypeDef GPIO_Initure;

    __HAL_RCC_GPIOA_CLK_ENABLE();           	//¿ªÆôGPIOAÊ±ÖÓ
	__HAL_RCC_GPIOD_CLK_ENABLE();           	//¿ªÆôGPIODÊ±ÖÓ

    GPIO_Initure.Pin=GPIO_PIN_8; 				//PB8
    GPIO_Initure.Mode=GPIO_MODE_OUTPUT_PP;  	//ÍÆÍìÊä³ö
    GPIO_Initure.Pull=GPIO_PULLUP;          	//ÉÏÀ­
    GPIO_Initure.Speed=GPIO_SPEED_FREQ_HIGH;    //¸ßËÙ
    HAL_GPIO_Init(GPIOA,&GPIO_Initure);

	GPIO_Initure.Pin=GPIO_PIN_2; 				//PD2
	HAL_GPIO_Init(GPIOD,&GPIO_Initure);

    HAL_GPIO_WritePin(GPIOA,GPIO_PIN_8,GPIO_PIN_SET);	//PA8ÖÃ1£¬Ä¬ÈÏ³õÊ¼»¯ºóµÆÃð
    HAL_GPIO_WritePin(GPIOD,GPIO_PIN_2,GPIO_PIN_SET);	//PD2ÖÃ1£¬Ä¬ÈÏ³õÊ¼»¯ºóµÆÃð
}


/* USER CODE BEGIN 2 */

/* USER CODE END 2 */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
