#ifndef  __UART2_H__
#define  __UART2_H__

#include "sys.h"



#define USART2_MAX_RECV_LEN		400					//×î´ó½ÓÊÕ»º´æ×Ö½ÚÊý
#define USART2_MAX_SEND_LEN		400					//×î´ó·¢ËÍ»º´æ×Ö½ÚÊý
#define USART2_RX_EN 			1					//0,²»½ÓÊÕ;1,½ÓÊÕ.

extern u8  USART2_RX_BUF[USART2_MAX_RECV_LEN]; 		//½ÓÊÕ»º³å,×î´óUSART2_MAX_RECV_LEN×Ö½Ú
extern u8  USART2_TX_BUF[USART2_MAX_SEND_LEN]; 		//·¢ËÍ»º³å,×î´óUSART2_MAX_SEND_LEN×Ö½Ú
extern vu16 USART2_RX_STA;   						//½ÓÊÕÊý¾Ý×´Ì¬

void USART2_Init(u32 bound);
void u2_printf(char* fmt,...);



#endif


